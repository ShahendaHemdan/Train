export  enum TrainClass {
    FirstClass = 'first Class',
    SecondClass = 'second Class',
    
    }
