export enum UserRole {
    ADMIN = 'admin',
    STATION_MASTER = 'station master',
    CLIENT = 'client',
    }