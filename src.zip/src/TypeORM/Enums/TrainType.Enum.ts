export enum TrainType {
    Express = 'Express Train',
    Local = 'Local Train',
    Vip = 'Super Fast Train',
    }